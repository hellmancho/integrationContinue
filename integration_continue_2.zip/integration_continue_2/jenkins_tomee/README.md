# jenkins-server
Création d'un serveur Tomcat/Jenkins dans un conteneur LXC avec ansible
